-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bus_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `seat_details`
--

DROP TABLE IF EXISTS `seat_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seat_details` (
  `SEAT_ID` int NOT NULL AUTO_INCREMENT,
  `TRAVEL_ID` int DEFAULT NULL,
  `BUS_ID` int DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `SEAT_NUMBER` int DEFAULT NULL,
  `SEAT_STATUS` varchar(10) DEFAULT 'Available',
  PRIMARY KEY (`SEAT_ID`),
  KEY `TRAVEL_ID` (`TRAVEL_ID`),
  KEY `BUS_ID` (`BUS_ID`),
  CONSTRAINT `seat_details_ibfk_1` FOREIGN KEY (`TRAVEL_ID`) REFERENCES `travel_details` (`TRAVEL_ID`),
  CONSTRAINT `seat_details_ibfk_2` FOREIGN KEY (`BUS_ID`) REFERENCES `bus_details` (`BUS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=701 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seat_details`
--

LOCK TABLES `seat_details` WRITE;
/*!40000 ALTER TABLE `seat_details` DISABLE KEYS */;
INSERT INTO `seat_details` VALUES (651,58,10,0,1,'Available'),(652,58,10,0,2,'Available'),(653,58,10,0,3,'Available'),(654,58,10,0,4,'Available'),(655,58,10,0,5,'Available'),(656,58,10,0,6,'Available'),(657,58,10,0,7,'Available'),(658,58,10,0,8,'Available'),(659,58,10,0,9,'Available'),(660,58,10,0,10,'Available'),(661,58,10,0,11,'Available'),(662,58,10,0,12,'Available'),(663,58,10,0,13,'Available'),(664,58,10,0,14,'Available'),(665,58,10,0,15,'Available'),(666,58,10,0,16,'Available'),(667,58,10,1,17,'Temporary'),(668,58,10,1,18,'Temporary'),(669,58,10,1,19,'Temporary'),(670,58,10,1,20,'Temporary'),(671,58,10,0,21,'Available'),(672,58,10,0,22,'Available'),(673,58,10,0,23,'Available'),(674,58,10,0,24,'Available'),(675,58,10,0,25,'Available'),(676,58,10,0,26,'Available'),(677,58,10,1,27,'Temporary'),(678,58,10,0,28,'Available'),(679,58,10,0,29,'Available'),(680,58,10,0,30,'Available'),(681,58,10,0,31,'Available'),(682,58,10,0,32,'Available'),(683,58,10,0,33,'Available'),(684,58,10,0,34,'Available'),(685,58,10,0,35,'Available'),(686,58,10,0,36,'Available'),(687,58,10,0,37,'Available'),(688,58,10,0,38,'Available'),(689,58,10,0,39,'Available'),(690,58,10,0,40,'Available'),(691,58,10,0,41,'Available'),(692,58,10,0,42,'Available'),(693,58,10,0,43,'Available'),(694,58,10,0,44,'Available'),(695,58,10,0,45,'Available'),(696,58,10,0,46,'Available'),(697,58,10,0,47,'Available'),(698,58,10,0,48,'Available'),(699,58,10,0,49,'Available'),(700,58,10,0,50,'Available');
/*!40000 ALTER TABLE `seat_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-30 14:14:33
