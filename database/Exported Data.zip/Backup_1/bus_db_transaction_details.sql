-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bus_db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction_details`
--

DROP TABLE IF EXISTS `transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_details` (
  `TRANSACTION_ID` int NOT NULL AUTO_INCREMENT,
  `USER_ID` int DEFAULT NULL,
  `AMOUNT` int DEFAULT NULL,
  `ACTION` varchar(10) DEFAULT NULL,
  `BALANCE` int DEFAULT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `TRANSACTION_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TRANSACTION_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_details`
--

LOCK TABLES `transaction_details` WRITE;
/*!40000 ALTER TABLE `transaction_details` DISABLE KEYS */;
INSERT INTO `transaction_details` VALUES (14,1,1250,'Debit',8750,'Wallet paid booking cost INR 1250 to MyJourney','2023-04-25 09:51:08'),(15,0,1250,'Credit',1001250,'User ID: 1 paid booking cost INR 1250 from Wallet','2023-04-25 09:51:08'),(16,1,1250,'Credit',10000,'Wallet received INR 1250 refund from MyJourney','2023-04-25 09:51:47'),(17,0,1250,'Debit',1000000,'MyJourney refunded booking cost INR 1250 to Wallet (User ID: 1)','2023-04-25 09:51:47'),(18,0,1250,'Debit',1000000,'Wallet paid booking cost INR 1250 to MyJourney','2023-04-25 10:39:01'),(19,0,1250,'Credit',1000000,'User ID: 0 paid booking cost INR 1250 from Wallet','2023-04-25 10:39:01'),(20,1,10000,'Credit',20000,'Wallet received INR 10000 from Card (8642 3579 0864 1346)','2023-04-25 10:55:03'),(21,0,1250,'Credit',1000000,'Wallet received INR 1250 refund from MyJourney','2023-04-26 04:55:53'),(22,0,1250,'Debit',1000000,'MyJourney refunded booking cost INR 1250 to Wallet (User ID: 0)','2023-04-26 04:55:53'),(23,1,2500,'Debit',17500,'Wallet paid booking cost INR 2500 to MyJourney','2023-04-26 06:04:18'),(24,0,2500,'Credit',1002500,'User ID: 1 paid booking cost INR 2500 from Wallet','2023-04-26 06:04:18'),(25,4,2500,'Debit',7500,'Wallet paid booking cost INR 2500 to MyJourney','2023-04-26 06:09:50'),(26,0,2500,'Credit',1005000,'User ID: 4 paid booking cost INR 2500 from Wallet','2023-04-26 06:09:50'),(27,4,2500,'Debit',5000,'Wallet paid booking cost INR 2500 to MyJourney','2023-04-26 06:10:21'),(28,0,2500,'Credit',1007500,'User ID: 4 paid booking cost INR 2500 from Wallet','2023-04-26 06:10:21'),(29,4,5000,'Debit',0,'Wallet paid booking cost INR 5000 to MyJourney','2023-04-26 08:43:50'),(30,0,5000,'Credit',1012500,'User ID: 4 paid booking cost INR 5000 from Wallet','2023-04-26 08:43:50'),(31,0,2500,'Debit',1012500,'Wallet paid booking cost INR 2500 to MyJourney','2023-04-27 10:22:16'),(32,0,2500,'Credit',1012500,'User ID: 0 paid booking cost INR 2500 from Wallet','2023-04-27 10:22:16'),(33,1,2500,'Credit',20000,'Wallet received INR 2500 refund from MyJourney','2023-04-28 12:13:19'),(34,0,2500,'Debit',1010000,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 1)','2023-04-28 12:13:19'),(35,4,2500,'Credit',2500,'Wallet received INR 2500 refund from MyJourney','2023-04-28 12:13:19'),(36,0,2500,'Debit',1007500,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 4)','2023-04-28 12:13:19'),(37,4,2500,'Credit',5000,'Wallet received INR 2500 refund from MyJourney','2023-04-28 12:13:19'),(38,0,2500,'Debit',1005000,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 4)','2023-04-28 12:13:19'),(39,0,2500,'Credit',1005000,'Wallet received INR 2500 refund from MyJourney','2023-04-28 12:13:19'),(40,0,2500,'Debit',1005000,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 0)','2023-04-28 12:13:19'),(41,4,5000,'Credit',10000,'Wallet received INR 5000 refund from MyJourney','2023-04-28 12:13:20'),(42,0,5000,'Debit',1000000,'MyJourney refunded booking cost INR 5000 to Wallet (User ID: 4)','2023-04-28 12:13:20'),(43,0,2500,'Debit',1000000,'Wallet paid booking cost INR 2500 to MyJourney','2023-05-16 09:11:01'),(44,0,2500,'Credit',1000000,'User ID: 0 paid booking cost INR 2500 from Wallet','2023-05-16 09:11:01'),(45,1,2500,'Debit',17500,'Wallet paid booking cost INR 2500 to MyJourney','2023-05-16 09:13:45'),(46,0,2500,'Credit',1002500,'User ID: 1 paid booking cost INR 2500 from Wallet','2023-05-16 09:13:45'),(47,0,2500,'Credit',1002500,'Wallet received INR 2500 refund from MyJourney','2023-05-18 12:12:57'),(48,0,2500,'Debit',1002500,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 0)','2023-05-18 12:12:57'),(49,1,2500,'Credit',20000,'Wallet received INR 2500 refund from MyJourney','2023-05-18 12:12:57'),(50,0,2500,'Debit',1000000,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 1)','2023-05-18 12:12:57'),(51,0,2500,'Debit',1000000,'Wallet paid booking cost INR 2500 to MyJourney','2023-05-18 12:15:54'),(52,0,2500,'Credit',1000000,'User ID: 0 paid booking cost INR 2500 from Wallet','2023-05-18 12:15:54'),(53,0,2500,'Credit',1000000,'Wallet received INR 2500 refund from MyJourney','2023-05-18 12:16:12'),(54,0,2500,'Debit',1000000,'MyJourney refunded booking cost INR 2500 to Wallet (User ID: 0)','2023-05-18 12:16:12'),(55,0,5000,'Credit',1005000,'Wallet received INR 5000 from Card (0192 8374 6501 9283)','2023-05-18 12:17:08');
/*!40000 ALTER TABLE `transaction_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-30 14:14:34
